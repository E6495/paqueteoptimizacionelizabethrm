from .bounding import bounding_phase_method
from .exhaustiva import exhaustive_search_method
from .intervalhalving import interval_halving_method
from .fibonacci import fibonacci, fibonacci_search
from .golden import regla_eliminacion, w_to_x, busquedaDorada